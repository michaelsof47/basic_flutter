class GeneralPassData {
  var nama = "";
  var age = "";
  var address = "";

  GeneralPassData({
    required this.nama,
    required this.age,
    required this.address,
  });
}
